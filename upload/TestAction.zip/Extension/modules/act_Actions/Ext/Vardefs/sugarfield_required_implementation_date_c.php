<?php
 // created: 2022-04-27 06:46:01
$dictionary['act_Actions']['fields']['required_implementation_date_c']['labelValue']='Estimated Completion Date';
$dictionary['act_Actions']['fields']['required_implementation_date_c']['enforced']='';
$dictionary['act_Actions']['fields']['required_implementation_date_c']['dependency']='';
$dictionary['act_Actions']['fields']['required_implementation_date_c']['required_formula']='';
$dictionary['act_Actions']['fields']['required_implementation_date_c']['readonly_formula']='';

 ?>