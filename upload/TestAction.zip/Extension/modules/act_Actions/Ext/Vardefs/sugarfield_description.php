<?php
 // created: 2022-04-05 07:54:12
$dictionary['act_Actions']['fields']['description']['audited']=false;
$dictionary['act_Actions']['fields']['description']['massupdate']=false;
$dictionary['act_Actions']['fields']['description']['hidemassupdate']=false;
$dictionary['act_Actions']['fields']['description']['comments']='Full text of the note';
$dictionary['act_Actions']['fields']['description']['duplicate_merge']='enabled';
$dictionary['act_Actions']['fields']['description']['duplicate_merge_dom_value']='1';
$dictionary['act_Actions']['fields']['description']['merge_filter']='disabled';
$dictionary['act_Actions']['fields']['description']['unified_search']=false;
$dictionary['act_Actions']['fields']['description']['full_text_search']=array (
  'enabled' => true,
  'boost' => '0.5',
  'searchable' => true,
);
$dictionary['act_Actions']['fields']['description']['calculated']=false;
$dictionary['act_Actions']['fields']['description']['rows']='6';
$dictionary['act_Actions']['fields']['description']['cols']='80';

 ?>