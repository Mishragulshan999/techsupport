<?php
 // created: 2022-04-27 06:46:02
$dictionary['act_Actions']['fields']['status_hielight_c']['labelValue']='status hielight';
$dictionary['act_Actions']['fields']['status_hielight_c']['dependency']='';
$dictionary['act_Actions']['fields']['status_hielight_c']['required_formula']='';
$dictionary['act_Actions']['fields']['status_hielight_c']['readonly_formula']='';
$dictionary['act_Actions']['fields']['status_hielight_c']['visibility_grid']='';

 ?>