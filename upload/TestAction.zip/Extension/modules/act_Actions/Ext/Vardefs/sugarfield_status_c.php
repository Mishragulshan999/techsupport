<?php
 // created: 2022-04-28 13:26:47
$dictionary['act_Actions']['fields']['status_c']['labelValue']='Status';
$dictionary['act_Actions']['fields']['status_c']['dependency']='';
$dictionary['act_Actions']['fields']['status_c']['required_formula']='';
$dictionary['act_Actions']['fields']['status_c']['readonly_formula']='';
$dictionary['act_Actions']['fields']['status_c']['visibility_grid']='';

 ?>