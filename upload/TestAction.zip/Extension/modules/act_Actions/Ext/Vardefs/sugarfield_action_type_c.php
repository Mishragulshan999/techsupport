<?php
 // created: 2022-04-28 13:02:51
$dictionary['act_Actions']['fields']['action_type_c']['labelValue']='Action Type';
$dictionary['act_Actions']['fields']['action_type_c']['dependency']='';
$dictionary['act_Actions']['fields']['action_type_c']['required_formula']='';
$dictionary['act_Actions']['fields']['action_type_c']['readonly_formula']='';
$dictionary['act_Actions']['fields']['action_type_c']['visibility_grid']='';

 ?>