<?php
 // created: 2022-03-31 05:50:19
$dictionary['act_Actions']['fields']['sync_key']['hidemassupdate']=false;
$dictionary['act_Actions']['fields']['sync_key']['importable']='false';
$dictionary['act_Actions']['fields']['sync_key']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['sync_key']['calculated']=false;

 ?>