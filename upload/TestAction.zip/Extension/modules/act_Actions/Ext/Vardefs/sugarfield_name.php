<?php
 // created: 2022-03-09 11:29:49
$dictionary['act_Actions']['fields']['name']['len']='255';
$dictionary['act_Actions']['fields']['name']['audited']=true;
$dictionary['act_Actions']['fields']['name']['massupdate']=false;
$dictionary['act_Actions']['fields']['name']['hidemassupdate']=false;
$dictionary['act_Actions']['fields']['name']['importable']='false';
$dictionary['act_Actions']['fields']['name']['duplicate_merge']='disabled';
$dictionary['act_Actions']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['act_Actions']['fields']['name']['merge_filter']='disabled';
$dictionary['act_Actions']['fields']['name']['unified_search']=false;
$dictionary['act_Actions']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.55',
  'searchable' => true,
);
$dictionary['act_Actions']['fields']['name']['calculated']=false;
$dictionary['act_Actions']['fields']['name']['help']='help1';

 ?>