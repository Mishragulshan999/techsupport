<?php
 // created: 2022-04-28 13:24:01
$dictionary['act_Actions']['fields']['finalresult_c']['labelValue']='Final Result';
$dictionary['act_Actions']['fields']['finalresult_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['finalresult_c']['enforced']='false';
$dictionary['act_Actions']['fields']['finalresult_c']['dependency']='';
$dictionary['act_Actions']['fields']['finalresult_c']['required_formula']='';
$dictionary['act_Actions']['fields']['finalresult_c']['readonly_formula']='';

 ?>