<?php
 // created: 2022-04-27 06:46:00
$dictionary['act_Actions']['fields']['due_date_c']['labelValue']='Over Due Date';
$dictionary['act_Actions']['fields']['due_date_c']['enforced']='';
$dictionary['act_Actions']['fields']['due_date_c']['dependency']='';
$dictionary['act_Actions']['fields']['due_date_c']['required_formula']='';
$dictionary['act_Actions']['fields']['due_date_c']['readonly_formula']='';

 ?>