<?php
 // created: 2022-04-28 13:29:13
$dictionary['act_Actions']['fields']['completion_date_c']['labelValue']='Completion Date';
$dictionary['act_Actions']['fields']['completion_date_c']['enforced']='';
$dictionary['act_Actions']['fields']['completion_date_c']['dependency']='';
$dictionary['act_Actions']['fields']['completion_date_c']['required_formula']='';
$dictionary['act_Actions']['fields']['completion_date_c']['readonly_formula']='';

 ?>