<?php
 // created: 2022-04-28 13:25:14
$dictionary['act_Actions']['fields']['responsible_participant_c']['labelValue']='Responsible Participant';
$dictionary['act_Actions']['fields']['responsible_participant_c']['dependency']='';
$dictionary['act_Actions']['fields']['responsible_participant_c']['required_formula']='';
$dictionary['act_Actions']['fields']['responsible_participant_c']['readonly_formula']='';
$dictionary['act_Actions']['fields']['responsible_participant_c']['visibility_grid']='';

 ?>