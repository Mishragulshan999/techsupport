<?php
 // created: 2022-04-27 06:46:01
$dictionary['act_Actions']['fields']['final_action_c']['labelValue']='Final Action';
$dictionary['act_Actions']['fields']['final_action_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['final_action_c']['enforced']='';
$dictionary['act_Actions']['fields']['final_action_c']['dependency']='equal($action_type_c,"Final Actions")';
$dictionary['act_Actions']['fields']['final_action_c']['required_formula']='';
$dictionary['act_Actions']['fields']['final_action_c']['readonly_formula']='';

 ?>