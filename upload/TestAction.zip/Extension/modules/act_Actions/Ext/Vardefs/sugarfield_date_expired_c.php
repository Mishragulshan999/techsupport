<?php
 // created: 2022-04-27 06:46:00
$dictionary['act_Actions']['fields']['date_expired_c']['labelValue']='Date Expired';
$dictionary['act_Actions']['fields']['date_expired_c']['dependency']='';
$dictionary['act_Actions']['fields']['date_expired_c']['required_formula']='';
$dictionary['act_Actions']['fields']['date_expired_c']['readonly_formula']='';
$dictionary['act_Actions']['fields']['date_expired_c']['visibility_grid']='';

 ?>