<?php
 // created: 2022-04-27 06:46:00
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['duplicate_merge_dom_value']=0;
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['labelValue']='complaint relate id';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['calculated']='true';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['formula']='related($com_complaints_act_actions_1,"id")';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['enforced']='true';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['dependency']='';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['required_formula']='';
$dictionary['act_Actions']['fields']['complaint_relate_id_c']['readonly_formula']='';

 ?>