<?php
 // created: 2022-04-27 06:46:00
$dictionary['act_Actions']['fields']['containment_actions_c']['labelValue']='Containment Actions';
$dictionary['act_Actions']['fields']['containment_actions_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['containment_actions_c']['enforced']='';
$dictionary['act_Actions']['fields']['containment_actions_c']['dependency']='equal($action_type_c,"Containment Actions")';
$dictionary['act_Actions']['fields']['containment_actions_c']['required_formula']='';
$dictionary['act_Actions']['fields']['containment_actions_c']['readonly_formula']='';

 ?>