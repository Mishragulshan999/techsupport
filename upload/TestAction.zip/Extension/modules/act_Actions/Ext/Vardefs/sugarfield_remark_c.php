<?php
 // created: 2022-04-27 12:44:02
$dictionary['act_Actions']['fields']['remark_c']['labelValue']='Remark';
$dictionary['act_Actions']['fields']['remark_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['remark_c']['enforced']='false';
$dictionary['act_Actions']['fields']['remark_c']['dependency']='';
$dictionary['act_Actions']['fields']['remark_c']['readonly_formula']='';

 ?>