<?php
 // created: 2022-04-28 13:33:00
$dictionary['act_Actions']['fields']['over_due_date_c']['duplicate_merge_dom_value']=0;
$dictionary['act_Actions']['fields']['over_due_date_c']['labelValue']='Over Due Days';
$dictionary['act_Actions']['fields']['over_due_date_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['over_due_date_c']['calculated']='1';
$dictionary['act_Actions']['fields']['over_due_date_c']['formula']='ifElse(not(equal($status_c,"Closed")),abs(subtract(daysUntil($date_entered),daysUntil($completion_date_c))),0)';
$dictionary['act_Actions']['fields']['over_due_date_c']['enforced']='1';
$dictionary['act_Actions']['fields']['over_due_date_c']['dependency']='';
$dictionary['act_Actions']['fields']['over_due_date_c']['required_formula']='';
$dictionary['act_Actions']['fields']['over_due_date_c']['readonly_formula']='';

 ?>