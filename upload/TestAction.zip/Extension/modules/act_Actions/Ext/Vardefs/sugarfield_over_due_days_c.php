<?php
 // created: 2022-04-27 06:46:01
$dictionary['act_Actions']['fields']['over_due_days_c']['duplicate_merge_dom_value']=0;
$dictionary['act_Actions']['fields']['over_due_days_c']['labelValue']='Over Due Days';
$dictionary['act_Actions']['fields']['over_due_days_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['over_due_days_c']['calculated']='1';
$dictionary['act_Actions']['fields']['over_due_days_c']['formula']='divide(abs(subtract(hoursUntil($completion_date_c),hoursUntil(today()))),24)';
$dictionary['act_Actions']['fields']['over_due_days_c']['enforced']='1';
$dictionary['act_Actions']['fields']['over_due_days_c']['dependency']='';
$dictionary['act_Actions']['fields']['over_due_days_c']['required_formula']='';
$dictionary['act_Actions']['fields']['over_due_days_c']['readonly_formula']='';

 ?>