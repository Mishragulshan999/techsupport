<?php
// created: 2022-04-28 13:33:11
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_name.php' => 
  array (
    'md5' => 'ec250608a3d35e492138b04bc4bc3c9d',
    'mtime' => 1646825389,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/full_text_search_admin.php' => 
  array (
    'md5' => 'b955c0be8f4447d3b3b624f4fd064933',
    'mtime' => 1648039610,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/com_complaints_act_actions_1_act_Actions.php' => 
  array (
    'md5' => '94226b49116524d95caa1509d7f237cf',
    'mtime' => 1648451805,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_sync_key.php' => 
  array (
    'md5' => '5038752ca6da2d338681614b2ec2c8e6',
    'mtime' => 1648705819,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_description.php' => 
  array (
    'md5' => '77e9ffd7941a14c9220d9cbebefdbb82',
    'mtime' => 1649145252,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_estimated_completion_date_c.php' => 
  array (
    'md5' => '1703cd6ce405851b7598f1472a7fd613',
    'mtime' => 1649324670,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_dummyckeditor_c.php' => 
  array (
    'md5' => '1703cd6ce405851b7598f1472a7fd613',
    'mtime' => 1649324670,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_result_2_c.php' => 
  array (
    'md5' => '0ff8b5b8bd21a922ec5ea3f0c95e9790',
    'mtime' => 1649324674,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_complaint_relate_id_c.php' => 
  array (
    'md5' => '5ca7d458377bb8bdcb9ac651a3c09217',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_assigned_to_c.php' => 
  array (
    'md5' => '8c77b1e01771d0fbc5fbe0a2f73d6c5b',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_containment_actions_c.php' => 
  array (
    'md5' => '7fb36757d5ee1152ba41f68898e95eba',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_corrective_actions_c.php' => 
  array (
    'md5' => 'ef46bc8c7fe1d799ae7c4635ee40b215',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_due_date_c.php' => 
  array (
    'md5' => '02c8cecb36c99535a9715fb48c4c57e7',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_date_expired_c.php' => 
  array (
    'md5' => '565873ef3c82a0a467bb46d3031966e8',
    'mtime' => 1651041960,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_final_action_c.php' => 
  array (
    'md5' => '511a2a53b1fa838785d8a6adf38dd274',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_improvement_action_c.php' => 
  array (
    'md5' => '196e23e087559674647c31f2084cc4d4',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_long_term_action_c.php' => 
  array (
    'md5' => 'cd108737aa91d3030692b551aeb588a1',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_pu_02_pu_master_id_c.php' => 
  array (
    'md5' => '2c2339cbe369f054406b6689b0988a15',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_short_term_action_c.php' => 
  array (
    'md5' => 'b6678da1a0c377278c6b277431a7cc1d',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_required_implementation_date_c.php' => 
  array (
    'md5' => 'b69c63bf8299b5d1f887e0b5311bd795',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_over_due_days_c.php' => 
  array (
    'md5' => 'b4e961d68cb011c710bba4cecd2858d5',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_open_action_days_c.php' => 
  array (
    'md5' => 'e92b1e2138858cb65e6b48c2db17580a',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_implementation_due_days_c.php' => 
  array (
    'md5' => '3c2f3da96eb678b8839db555cc7063c5',
    'mtime' => 1651041961,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_status_hielight_c.php' => 
  array (
    'md5' => 'a5213c25b9835b9b14243f99414ee141',
    'mtime' => 1651041962,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_user_id_c.php' => 
  array (
    'md5' => 'd530b7ad4aea95360200125cd9145e52',
    'mtime' => 1651041962,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_remark_c.php' => 
  array (
    'md5' => '2422e5da38643735bbac14c4db9343d3',
    'mtime' => 1651063442,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_action_type_c.php' => 
  array (
    'md5' => 'e3ee16276c365f1bd7ac9e6bcb59a3f2',
    'mtime' => 1651150971,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_finalresult_c.php' => 
  array (
    'md5' => '6fb5776d6db3fd4027c91d3ef881f944',
    'mtime' => 1651152241,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_responsible_participant_c.php' => 
  array (
    'md5' => 'c49f51acc52a0b5759ced5cbabe3d2c5',
    'mtime' => 1651152314,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_status_c.php' => 
  array (
    'md5' => '256e7e41b9540854fb51c1bb60fb295e',
    'mtime' => 1651152407,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_completion_date_c.php' => 
  array (
    'md5' => 'b556d14d77198a3473508016fe6e2a5f',
    'mtime' => 1651152553,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Vardefs/sugarfield_over_due_date_c.php' => 
  array (
    'md5' => '425deb7b40bed59fa31b13995624ee5e',
    'mtime' => 1651152780,
    'is_override' => false,
  ),
);