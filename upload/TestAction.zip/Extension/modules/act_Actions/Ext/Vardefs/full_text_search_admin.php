<?php
 // created: 2022-03-23 12:46:50
$dictionary['act_Actions']['full_text_search']=true;
