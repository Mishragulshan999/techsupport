<?php
 // created: 2022-04-27 06:46:01
$dictionary['act_Actions']['fields']['open_action_days_c']['duplicate_merge_dom_value']=0;
$dictionary['act_Actions']['fields']['open_action_days_c']['labelValue']='Open Action Days';
$dictionary['act_Actions']['fields']['open_action_days_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['act_Actions']['fields']['open_action_days_c']['calculated']='1';
$dictionary['act_Actions']['fields']['open_action_days_c']['formula']='abs(subtract(daysUntil($date_entered),daysUntil($completion_date_c)))';
$dictionary['act_Actions']['fields']['open_action_days_c']['enforced']='1';
$dictionary['act_Actions']['fields']['open_action_days_c']['dependency']='';
$dictionary['act_Actions']['fields']['open_action_days_c']['required_formula']='';
$dictionary['act_Actions']['fields']['open_action_days_c']['readonly_formula']='';

 ?>