<?php
// created: 2022-04-05 07:29:14
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '9590c6b0716afc3a233b7e42e3dae451',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);