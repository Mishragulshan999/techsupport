<?php
// created: 2022-04-27 06:39:36
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LT.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5b719384c4a4dc215a254476f95d7ce4',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '06481303c2d483dbe669159b3141aa67',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5b719384c4a4dc215a254476f95d7ce4',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f31f1f4f780bff17c9bea1a9cabd3e8f',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);