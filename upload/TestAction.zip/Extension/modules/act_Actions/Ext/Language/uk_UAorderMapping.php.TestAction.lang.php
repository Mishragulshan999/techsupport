<?php
// created: 2022-04-27 06:40:37
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '980389ff87732930df88aeb7da9f36da',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9590c6b0716afc3a233b7e42e3dae451',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);