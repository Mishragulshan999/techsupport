<?php
// created: 2022-02-20 16:52:17
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.lang.php' => 
  array (
    'md5' => '9f3b8de562efb30bc85d0a38cc1fdee8',
    'mtime' => 1644837664,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => 'ef8f5167c6948fdb72c17ccc22db4c0d',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
);