<?php
// created: 2022-04-05 07:29:11
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RS.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '422655f24e83a8cc50973b5a143b4f17',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '422655f24e83a8cc50973b5a143b4f17',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '15bbf285c4547e6e534502d35f6a48da',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);