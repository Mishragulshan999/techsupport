<?php
// created: 2022-04-27 06:39:49
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9c6396d06b752dc177ae0a0412e8da76',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd2164af5b244cbc646ba5cf185a6167e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9c6396d06b752dc177ae0a0412e8da76',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '66a72fde076a8c3a6345d0c861fdb410',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);