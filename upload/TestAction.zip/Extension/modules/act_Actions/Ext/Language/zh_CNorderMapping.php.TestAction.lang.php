<?php
// created: 2022-04-27 06:40:10
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CN.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b4d6e8b41d5c8d0c3cc03946b5b0aa2d',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '189892717a22be4d170ca40608b2d1db',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b4d6e8b41d5c8d0c3cc03946b5b0aa2d',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9005a2f6a801247392665c41ed22bef5',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);