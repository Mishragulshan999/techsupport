<?php
// created: 2022-02-14 19:09:10
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644397356,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1644845379,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.customact_actions_com_complaints_1.php' => 
  array (
    'md5' => '04d0bc8efd70043d603338a22ae43903',
    'mtime' => 1644845940,
    'is_override' => false,
  ),
);