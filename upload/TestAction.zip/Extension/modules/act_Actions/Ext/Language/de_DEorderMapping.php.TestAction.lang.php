<?php
// created: 2022-04-27 06:39:17
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/de_DE.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b1e2026638b9801ae5cb69d16a2e35f5',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c36da50c4be5b9e1bd93b52ad11f6862',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b1e2026638b9801ae5cb69d16a2e35f5',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '7a48af91e218827eb7bbdf7521d59799',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);