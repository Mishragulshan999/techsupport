<?php
// created: 2022-04-27 06:39:31
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'eb89ac6e030743d712466ee850bbc525',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '954cce475bf99a1f284119c4570db1a7',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);