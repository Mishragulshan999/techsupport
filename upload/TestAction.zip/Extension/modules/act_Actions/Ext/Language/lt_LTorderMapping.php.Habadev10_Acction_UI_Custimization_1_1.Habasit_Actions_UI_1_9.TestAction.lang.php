<?php
// created: 2022-02-14 19:09:09
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LT.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644397356,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LT.customact_actions_com_complaints_1.php' => 
  array (
    'md5' => '04d0bc8efd70043d603338a22ae43903',
    'mtime' => 1644845940,
    'is_override' => false,
  ),
);