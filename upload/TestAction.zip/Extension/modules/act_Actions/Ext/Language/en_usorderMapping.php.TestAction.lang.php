<?php
// created: 2022-04-28 13:33:00
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'afe65af8a68d8d2a4ba091b0cc047ec5',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ee2ff771b913b0daa069882fa395e721',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.send_action_acknowledgment_email_button.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4cc8f601438c6d26a3128ecbef3e5975',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f7617f189bedc122f1eb86754bc5f50e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.lang.php' => 
  array (
    'md5' => 'a7b56cbd7692a2d7fd29b48dac7790db',
    'mtime' => 1651152780,
    'is_override' => false,
  ),
);