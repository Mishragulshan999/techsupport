<?php
// created: 2022-04-28 15:07:24
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BG.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZ.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DE.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_EL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ES.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_IL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HU.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_it.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LT.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JP.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LV.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NO.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PT.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_RO.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RU.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SE.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_TH.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TW.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CN.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ES.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RS.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_AL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EE.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FI.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.lang.php' => 
  array (
    'md5' => 'c37217ecfce66bc96d1e19b1097dbf38',
    'mtime' => 1648796056,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php' => 
  array (
    'md5' => 'ab457514c71aaeb17b7f2e61e83e4468',
    'mtime' => 1651041549,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZorderMapping.php' => 
  array (
    'md5' => 'b5bf27f6ae001ede01f61666b31b751a',
    'mtime' => 1651041552,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DKorderMapping.php' => 
  array (
    'md5' => '7bf7345a6f37eb56a6a15bb5f2993455',
    'mtime' => 1651041554,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php' => 
  array (
    'md5' => '2d3b683450a6db721b27e7b345fa9f99',
    'mtime' => 1651041557,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php' => 
  array (
    'md5' => 'cab9e4f46311c8a041387fd87be54053',
    'mtime' => 1651041559,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php' => 
  array (
    'md5' => '622a318d3b5a670d049161109f2bf0c2',
    'mtime' => 1651041561,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php' => 
  array (
    'md5' => 'b304981e533f844dba162cb7bb682c91',
    'mtime' => 1651041564,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php' => 
  array (
    'md5' => 'c114a96cf7cab0312088cc2f3078eca0',
    'mtime' => 1651041566,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php' => 
  array (
    'md5' => '11a0c5447161d1cc923700e1922679a7',
    'mtime' => 1651041568,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php' => 
  array (
    'md5' => '3b9d138270a0df3e0163f025c7468429',
    'mtime' => 1651041571,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_itorderMapping.php' => 
  array (
    'md5' => '58fd840846e1c236b7475d92d26804dc',
    'mtime' => 1651041573,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php' => 
  array (
    'md5' => 'dc24c72ff09fc5418ee7a469d405802d',
    'mtime' => 1651041576,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JPorderMapping.php' => 
  array (
    'md5' => '992861548ccd212a066453a3f5e8062b',
    'mtime' => 1651041578,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php' => 
  array (
    'md5' => '024a3030d64aafb341b32fd1052002a2',
    'mtime' => 1651041580,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php' => 
  array (
    'md5' => '2db7834f2383b3df491e7d697a4c9e23',
    'mtime' => 1651041582,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php' => 
  array (
    'md5' => 'f4b80ab8149231f7b49e011211f7ad59',
    'mtime' => 1651041584,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php' => 
  array (
    'md5' => 'b358cf4bd3c0530d77836a2093261e8b',
    'mtime' => 1651041587,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php' => 
  array (
    'md5' => 'dcd2e8ac49287ac9180cca9b8958b9ec',
    'mtime' => 1651041589,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php' => 
  array (
    'md5' => '7e7f474783fc90fd4c066caa39cbf1e5',
    'mtime' => 1651041591,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php' => 
  array (
    'md5' => '26e877eac36f02b2495659363fd14023',
    'mtime' => 1651041594,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RUorderMapping.php' => 
  array (
    'md5' => '18534ed756b66350113916c786b2c23a',
    'mtime' => 1651041596,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SEorderMapping.php' => 
  array (
    'md5' => '9df1ba096538de97456f9cec8a3bb4c1',
    'mtime' => 1651041598,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_THorderMapping.php' => 
  array (
    'md5' => '09564199e7862d9bb2b465a8bd7fb487',
    'mtime' => 1651041600,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php' => 
  array (
    'md5' => '5f9fc11622945081ade06a9715e84348',
    'mtime' => 1651041603,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php' => 
  array (
    'md5' => 'd3cc33341607e9ed05ee360dd8b3553d',
    'mtime' => 1651041607,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php' => 
  array (
    'md5' => '7833482bf2cb8e5f559156718ab83832',
    'mtime' => 1651041610,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php' => 
  array (
    'md5' => '145c54055795f0e2bb2030d78cc05f03',
    'mtime' => 1651041613,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php' => 
  array (
    'md5' => 'cbc4e62602817cce1d70ed224a16826b',
    'mtime' => 1651041615,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php' => 
  array (
    'md5' => '1075538c4abbc53aa74baa9797485e97',
    'mtime' => 1651041618,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php' => 
  array (
    'md5' => 'aabdd5773b566ad99a204cd833130807',
    'mtime' => 1651041620,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SKorderMapping.php' => 
  array (
    'md5' => 'ef3b4ea5f2cbdcd82ec535643f4c7cdc',
    'mtime' => 1651041623,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_ALorderMapping.php' => 
  array (
    'md5' => '29ee46709fcafde8f910a409407e8bf4',
    'mtime' => 1651041625,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php' => 
  array (
    'md5' => '045f82492c4a0a6769508296edb04388',
    'mtime' => 1651041627,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php' => 
  array (
    'md5' => 'cba2ff9e437cf40d2592c39a844c283e',
    'mtime' => 1651041630,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php' => 
  array (
    'md5' => '7e626eb1e2572603644f613f4198409d',
    'mtime' => 1651041632,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php' => 
  array (
    'md5' => '0ebd03b9499c3ce3c8fb76dbd8e6c00b',
    'mtime' => 1651041634,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php' => 
  array (
    'md5' => 'fd6b546fc41394faede61b491bbfbf0e',
    'mtime' => 1651041637,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '98faf6ddd1407b4559c735ff657f0892',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '999aade6451e552f96043b6ad3ad3cc5',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '302ba99cdabca89cc61c7044d715909d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ef8f5167c6948fdb72c17ccc22db4c0d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '44910e20c3dc66363d8b16c1937464e9',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ec0d8bd96674a2e23903dbd155cc774e',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0a07e81a5de00980288d28b4a30b7d1e',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b1e2026638b9801ae5cb69d16a2e35f5',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '32d4d695d96ee91babafe327341f936c',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5ebfdcf830246f5aced0ad625b93d556',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bc68ff0268e955537eed4af43a702e1',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9b4566b1a85876638d7a6a346d602902',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2d3a509d4544a885c129b664ec6331e1',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_itorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9cea822a8e2cdb65f10e31582f6ece3f',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5b719384c4a4dc215a254476f95d7ce4',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JPorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '032423d70d7f078c715b8f7079e213f2',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '664876380d0008a46fc37d62aaffff4e',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60294b95e4c54f5eb71a9c893f98eac8',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bdabc09ebb5ff0c38b5644f139a13792',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9c6396d06b752dc177ae0a0412e8da76',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2c0fd884b8ba34a4647f7f68c26d5f2d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c9f36dae5fbd8a4674979626258d7d5',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3760f420b8ff16712c7cebb376c2e8bc',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_THorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a4ba3c6bf914d06166b687fd364aa1ad',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b4d6e8b41d5c8d0c3cc03946b5b0aa2d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0c7e2a085836c7350ad9ff640b0b19ef',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8187fbfe81352b351ed71874899564ce',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '422655f24e83a8cc50973b5a143b4f17',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e0df0a10a3bfe29855426835b291bc91',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_ALorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '916235c552ad01917d736941d5037763',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd28ab30ab82e13fe9942d6b47c9e2122',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3841756ab14986615bd12f8843c48d65',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ed12c1046def0f67f31c44489a33769d',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c35dba05b2a1de000d2b8d42069bc6e',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0372d2be4cdd4873ac7d9bb2facebdb5',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1651041848,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2387953817b9f62ea680457e289a3bd0',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a05ae7918acd07d1b1499513e55ec4ca',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DKorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'db0392424f933e1666ea7567eb6f625a',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c36da50c4be5b9e1bd93b52ad11f6862',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bbe39ff5900533541a8c755e19ca211c',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'afe65af8a68d8d2a4ba091b0cc047ec5',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'db0b40687b25c0b41cb361bbca61ddfe',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8e47c738c688342e000a00fa6770bc23',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'cf9f2aafff02b75ce549dbb8b565093a',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '76eb1268b164fa32067a2312c7df6310',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '54dc9f819ac15e4eb6be17bf1d7bb8b1',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '497cb6acfc2563f7468dabe64e4c9fb2',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'eb89ac6e030743d712466ee850bbc525',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '859cbb8f418180004f70d4ef45c89f53',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_itorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bddbb4d43caab2d7cb05e9fd6bcb21ed',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JPorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd2f6fc14f8bf4470370c6fb176fb4973',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd5c99ac0ae59240a73cecddcee606eb9',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '06481303c2d483dbe669159b3141aa67',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c187f4056c0d9fbf566e1e4e55cd215c',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a04d17f06baf7a0db08130cadc1a8e6e',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '537d58c64d133e27656064a1cd187122',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd2164af5b244cbc646ba5cf185a6167e',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0ef5c13b522d0b282fe1ee47ff6851df',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'fd829da6b8b925a82ec2de1717f88bab',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b403e280de731860370def599f5279b9',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RUorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'fc37663d16a07d91c76d1d79e371ae64',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SKorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0bafafdeabee773aaf62d725a07a6725',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_ALorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c1a1f38fd0fc10001c11a50fa5402e72',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '608705ac2028cb413978e469bfbea111',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SEorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '414e00ca05181bfcf9439bbf58ef374a',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_THorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9f290584ab8182dd2b8a2ad6755eee37',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2ee698dc459cb3b92c8354d3a0f6c616',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '980389ff87732930df88aeb7da9f36da',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '189892717a22be4d170ca40608b2d1db',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0e5cba4be511e6bda06d6acefa4cf434',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ee2ff771b913b0daa069882fa395e721',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '85e88d60ed0f4169e8884b51f1dc5f23',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9f3b8de562efb30bc85d0a38cc1fdee8',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60857092ea7781d8171d6ed017c94ce5',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ef8f5167c6948fdb72c17ccc22db4c0d',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '44910e20c3dc66363d8b16c1937464e9',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ec0d8bd96674a2e23903dbd155cc774e',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '234d9ec3d94bce7b517444055cd10264',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0a07e81a5de00980288d28b4a30b7d1e',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b1e2026638b9801ae5cb69d16a2e35f5',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '32d4d695d96ee91babafe327341f936c',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5ebfdcf830246f5aced0ad625b93d556',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bc68ff0268e955537eed4af43a702e1',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9b4566b1a85876638d7a6a346d602902',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2d3a509d4544a885c129b664ec6331e1',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_itorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9cea822a8e2cdb65f10e31582f6ece3f',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5b719384c4a4dc215a254476f95d7ce4',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JPorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '032423d70d7f078c715b8f7079e213f2',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '664876380d0008a46fc37d62aaffff4e',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60294b95e4c54f5eb71a9c893f98eac8',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bdabc09ebb5ff0c38b5644f139a13792',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9c6396d06b752dc177ae0a0412e8da76',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2c0fd884b8ba34a4647f7f68c26d5f2d',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c9f36dae5fbd8a4674979626258d7d5',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3760f420b8ff16712c7cebb376c2e8bc',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_THorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a4ba3c6bf914d06166b687fd364aa1ad',
    'mtime' => 1651041849,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b4d6e8b41d5c8d0c3cc03946b5b0aa2d',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0c7e2a085836c7350ad9ff640b0b19ef',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8187fbfe81352b351ed71874899564ce',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '422655f24e83a8cc50973b5a143b4f17',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e0df0a10a3bfe29855426835b291bc91',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_ALorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '916235c552ad01917d736941d5037763',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd28ab30ab82e13fe9942d6b47c9e2122',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3841756ab14986615bd12f8843c48d65',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c35dba05b2a1de000d2b8d42069bc6e',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0372d2be4cdd4873ac7d9bb2facebdb5',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.send_action_acknowledgment_email_button.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4cc8f601438c6d26a3128ecbef3e5975',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'edf12063f4ed5d3fcf66ed0846d7b6c1',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '1946d6aace6f051f3c8ed0f32f636a39',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/cs_CZorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '6c299d2d41cc0cb002dcf3a0f6f25d36',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/da_DKorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '17e6f728c8982196e8f1966b77818192',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/de_DEorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '7a48af91e218827eb7bbdf7521d59799',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bbbe8ac4f7aa2fcac50183e2c82cbc3',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f7617f189bedc122f1eb86754bc5f50e',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '963dffd3ff24ebb29654c677af0b4119',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a015e2ff357f7fa4a49710d388b8f627',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b93f890c4535557e61c8e316e06a90f2',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bf235646d5a7b3f3ae3b06fd95cbcf99',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '560875cc6592a40205f1c683d703c75a',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f446e12b721c7ba600d95cef0f0c56e3',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '954cce475bf99a1f284119c4570db1a7',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b00e4c14aadf8ae10533d8f0aad867c9',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/it_itorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '822263393065c0e907b0fbf505cab46f',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ja_JPorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60b607fbc1d75b81e21a93f803d5e62c',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '1c4403cd8737e854de316ec4576ad95c',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lt_LTorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f31f1f4f780bff17c9bea1a9cabd3e8f',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2683c3a799615eba934935aba6eb8498',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c2f35cb0f3d6acbaab19c93d8e189440',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ac142b95ffa65737cdf689d9cf088f88',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pl_PLorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '66a72fde076a8c3a6345d0c861fdb410',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '1357782016b3dea7b5bfc369f1b2dd07',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4f2aed21882b39bdd40dc99ec2813158',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b05b6c5cd1d1780e5ee8bcec8deaafb1',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ru_RUorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ecffa2b09ec572bdf59cf3d3b01a7e44',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sk_SKorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '77fe9ce4e26dcbfdd00c4420ddaa4a48',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sq_ALorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '6bd7c3dd305e786a7d171d81bb1284f4',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sr_RSorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '15bbf285c4547e6e534502d35f6a48da',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/sv_SEorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f43bc06bb7aeeaa14f66cdbfbb541c93',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/th_THorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '543409cd3a4589c2dcbef30d4bfc95a4',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b22f7817bf5d70d2a586f6118e6f1aa4',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/uk_UAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9590c6b0716afc3a233b7e42e3dae451',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_CNorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9005a2f6a801247392665c41ed22bef5',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0ecf79cb7fb70aa68c2d154d09074d17',
    'mtime' => 1651041850,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php' => 
  array (
    'md5' => '3a45ecbdddbb4d7eebdc78597e14cc55',
    'mtime' => 1651152780,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.lang.php' => 
  array (
    'md5' => 'a7b56cbd7692a2d7fd29b48dac7790db',
    'mtime' => 1651152780,
    'is_override' => false,
  ),
);