<?php
// created: 2022-04-27 06:39:42
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LV.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c187f4056c0d9fbf566e1e4e55cd215c',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2683c3a799615eba934935aba6eb8498',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);