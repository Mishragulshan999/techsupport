<?php
// created: 2022-04-27 06:40:27
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/et_EE.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd28ab30ab82e13fe9942d6b47c9e2122',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'cf9f2aafff02b75ce549dbb8b565093a',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd28ab30ab82e13fe9942d6b47c9e2122',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/et_EEorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b93f890c4535557e61c8e316e06a90f2',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);