<?php
// created: 2022-04-27 06:40:32
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FI.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c35dba05b2a1de000d2b8d42069bc6e',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '76eb1268b164fa32067a2312c7df6310',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3c35dba05b2a1de000d2b8d42069bc6e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fi_FIorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bf235646d5a7b3f3ae3b06fd95cbcf99',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);