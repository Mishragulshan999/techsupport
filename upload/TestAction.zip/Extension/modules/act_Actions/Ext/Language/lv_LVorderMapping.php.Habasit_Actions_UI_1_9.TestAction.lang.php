<?php
// created: 2022-04-05 07:29:03
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LV.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '9a57464748fdebb88b5abd5eb844f029',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/lv_LVorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '2683c3a799615eba934935aba6eb8498',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);