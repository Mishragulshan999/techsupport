<?php
// created: 2022-04-27 06:40:07
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TW.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0e5cba4be511e6bda06d6acefa4cf434',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0ecf79cb7fb70aa68c2d154d09074d17',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);