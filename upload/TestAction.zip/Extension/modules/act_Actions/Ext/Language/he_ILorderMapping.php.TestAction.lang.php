<?php
// created: 2022-04-27 06:39:26
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/he_IL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9b4566b1a85876638d7a6a346d602902',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '497cb6acfc2563f7468dabe64e4c9fb2',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9b4566b1a85876638d7a6a346d602902',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/he_ILorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'f446e12b721c7ba600d95cef0f0c56e3',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);