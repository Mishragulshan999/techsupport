<?php
// created: 2022-02-20 16:52:13
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BG.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/bg_BGorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '44910e20c3dc66363d8b16c1937464e9',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
);