<?php
// created: 2022-04-05 07:29:01
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '822a922a89560715c25a56e8fcc986c8',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hr_HRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '954cce475bf99a1f284119c4570db1a7',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);