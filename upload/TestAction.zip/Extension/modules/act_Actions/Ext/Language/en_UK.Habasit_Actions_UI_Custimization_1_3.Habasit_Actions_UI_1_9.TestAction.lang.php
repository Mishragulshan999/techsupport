<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_IMPROVEMENT_ACTION'] = 'Improvement Action';
$mod_strings['LBL_SHORT_TERM_ACTION'] = 'Short Term Action';
$mod_strings['LBL_LONG_TERM_ACTION'] = 'Long Term Action';
$mod_strings['LBL_REQUIRED_IMPLEMENTATION_DATE'] = 'Required Implementation Date';
$mod_strings['LBL_DESCRIPTION'] = 'Action Description';
$mod_strings['LBL_FINALRESULT'] = 'Final Result';
$mod_strings['LBL_COMPLETION_DATE'] = 'Completion Date';
$mod_strings['LBL_RESPONSIBLE_PARTICIPANT_PU_02_PU_MASTER_ID'] = 'Responsible Participant (related PU Master ID)';
$mod_strings['LBL_RESPONSIBLE_PARTICIPANT'] = 'Responsible Participant';
