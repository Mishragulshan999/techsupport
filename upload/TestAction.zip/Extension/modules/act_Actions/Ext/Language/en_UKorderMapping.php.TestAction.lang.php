<?php
// created: 2022-04-27 06:40:18
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.lang.php' => 
  array (
    'md5' => 'c37217ecfce66bc96d1e19b1097dbf38',
    'mtime' => 1648796056,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '999aade6451e552f96043b6ad3ad3cc5',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '302ba99cdabca89cc61c7044d715909d',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ef8f5167c6948fdb72c17ccc22db4c0d',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '9f3b8de562efb30bc85d0a38cc1fdee8',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60857092ea7781d8171d6ed017c94ce5',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UK.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd8e3e763de70a48b62aed1df64d06181',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_UKorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ef8f5167c6948fdb72c17ccc22db4c0d',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);