<?php
// created: 2022-04-27 06:40:34
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '98faf6ddd1407b4559c735ff657f0892',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0372d2be4cdd4873ac7d9bb2facebdb5',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '85e88d60ed0f4169e8884b51f1dc5f23',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '0372d2be4cdd4873ac7d9bb2facebdb5',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);