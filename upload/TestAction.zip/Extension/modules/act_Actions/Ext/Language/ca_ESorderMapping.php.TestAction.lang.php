<?php
// created: 2022-04-27 06:40:15
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ES.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8187fbfe81352b351ed71874899564ce',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2387953817b9f62ea680457e289a3bd0',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8187fbfe81352b351ed71874899564ce',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ca_ESorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '1946d6aace6f051f3c8ed0f32f636a39',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);