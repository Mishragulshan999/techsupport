<?php
// created: 2022-04-05 07:29:09
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'b22f7817bf5d70d2a586f6118e6f1aa4',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);