<?php
// created: 2022-04-27 06:39:51
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PT.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2c0fd884b8ba34a4647f7f68c26d5f2d',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'fd829da6b8b925a82ec2de1717f88bab',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2c0fd884b8ba34a4647f7f68c26d5f2d',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_PTorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4f2aed21882b39bdd40dc99ec2813158',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);