<?php
// created: 2022-04-05 07:29:09
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TW.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'c6c67a841aad7e37173c3dd598b7375e',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/zh_TWorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '0ecf79cb7fb70aa68c2d154d09074d17',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);