<?php
// created: 2022-04-27 06:39:28
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HU.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2d3a509d4544a885c129b664ec6331e1',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '859cbb8f418180004f70d4ef45c89f53',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2d3a509d4544a885c129b664ec6331e1',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/hu_HUorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b00e4c14aadf8ae10533d8f0aad867c9',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);