<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_STATUS'] = 'status';
$mod_strings['LBL_DATE_EXPIRED'] = 'Date Expired';
$mod_strings['LBL_ESTIMATED_COMPLETION_DATE'] = 'Estimated Completion Date';
$mod_strings['LBL_DESCRIPTION'] = 'Action Description';
$mod_strings['LBL_RESULT_2'] = 'result';
$mod_strings['LBL_OVER_DUE_DAYS'] = 'Over Due Days';
$mod_strings['LBL_IMPLEMENTATION_DUE_DAYS'] = 'Implementation Due Days';
$mod_strings['LBL_REQUIRED_IMPLEMENTATION_DATE'] = 'Estimated Completion Date';
$mod_strings['LBL_REMARK'] = 'Remark';
$mod_strings['LBL_DUMMYCKEDITOR'] = 'DummyCKeditor';
$mod_strings['LBL_OPEN_ACTION_DAYS_C'] = 'Open Action Days';
$mod_strings['LBL_OVER_DUE_DATE_C'] = 'Over Due Date';
