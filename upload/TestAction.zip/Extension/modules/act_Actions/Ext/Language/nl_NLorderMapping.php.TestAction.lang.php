<?php
// created: 2022-04-27 06:39:47
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bdabc09ebb5ff0c38b5644f139a13792',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '537d58c64d133e27656064a1cd187122',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bdabc09ebb5ff0c38b5644f139a13792',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nl_NLorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'ac142b95ffa65737cdf689d9cf088f88',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);