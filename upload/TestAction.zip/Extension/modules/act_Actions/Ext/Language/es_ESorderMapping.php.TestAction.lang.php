<?php
// created: 2022-04-27 06:39:21
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/es_ES.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5ebfdcf830246f5aced0ad625b93d556',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'db0b40687b25c0b41cb361bbca61ddfe',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '5ebfdcf830246f5aced0ad625b93d556',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_ESorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '963dffd3ff24ebb29654c677af0b4119',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);