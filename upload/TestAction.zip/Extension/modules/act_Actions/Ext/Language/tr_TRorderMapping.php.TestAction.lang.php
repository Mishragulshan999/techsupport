<?php
// created: 2022-04-27 06:40:03
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '2ee698dc459cb3b92c8354d3a0f6c616',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '62b1dd8ac6420333dd84227c658a933d',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/tr_TRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b22f7817bf5d70d2a586f6118e6f1aa4',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);