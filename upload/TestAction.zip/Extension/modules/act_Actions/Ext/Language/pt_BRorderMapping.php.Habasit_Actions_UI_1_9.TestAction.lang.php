<?php
// created: 2022-04-05 07:29:10
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '0c7e2a085836c7350ad9ff640b0b19ef',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '0c7e2a085836c7350ad9ff640b0b19ef',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/pt_BRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '1357782016b3dea7b5bfc369f1b2dd07',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);