<?php
// created: 2022-02-20 16:52:12
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ar_SAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '0372d2be4cdd4873ac7d9bb2facebdb5',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
);