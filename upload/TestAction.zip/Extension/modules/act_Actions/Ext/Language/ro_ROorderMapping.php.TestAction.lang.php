<?php
// created: 2022-04-27 06:39:54
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ro_RO.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b403e280de731860370def599f5279b9',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'b05b6c5cd1d1780e5ee8bcec8deaafb1',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);