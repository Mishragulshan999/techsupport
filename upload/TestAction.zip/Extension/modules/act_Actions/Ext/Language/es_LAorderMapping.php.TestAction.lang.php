<?php
// created: 2022-04-27 06:40:30
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/es_LA.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3841756ab14986615bd12f8843c48d65',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '8e47c738c688342e000a00fa6770bc23',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '3841756ab14986615bd12f8843c48d65',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/es_LAorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a015e2ff357f7fa4a49710d388b8f627',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);