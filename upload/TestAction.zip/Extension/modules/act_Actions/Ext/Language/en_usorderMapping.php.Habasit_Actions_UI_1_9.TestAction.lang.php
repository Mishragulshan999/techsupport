<?php
// created: 2022-04-21 08:06:36
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => '9dec282edb478fa7a0c5453e600a2cfa',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_usorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'f7617f189bedc122f1eb86754bc5f50e',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.send_action_acknowledgment_email_button.php' => 
  array (
    'md5' => '4cc8f601438c6d26a3128ecbef3e5975',
    'mtime' => 1649763164,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/en_us.lang.php' => 
  array (
    'md5' => 'ee2ff771b913b0daa069882fa395e721',
    'mtime' => 1650528396,
    'is_override' => false,
  ),
);