<?php
// created: 2022-04-27 06:39:24
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bc68ff0268e955537eed4af43a702e1',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '54dc9f819ac15e4eb6be17bf1d7bb8b1',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bc68ff0268e955537eed4af43a702e1',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/fr_FRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '560875cc6592a40205f1c683d703c75a',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);