<?php
// created: 2022-04-27 06:39:19
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/el_EL.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '32d4d695d96ee91babafe327341f936c',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'bbe39ff5900533541a8c755e19ca211c',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '32d4d695d96ee91babafe327341f936c',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/el_ELorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '4bbbe8ac4f7aa2fcac50183e2c82cbc3',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);