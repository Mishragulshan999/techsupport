<?php
// created: 2022-04-27 06:39:44
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NO.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60294b95e4c54f5eb71a9c893f98eac8',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'a04d17f06baf7a0db08130cadc1a8e6e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '60294b95e4c54f5eb71a9c893f98eac8',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/nb_NOorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'c2f35cb0f3d6acbaab19c93d8e189440',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);