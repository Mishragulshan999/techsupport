<?php
// created: 2022-04-27 06:39:40
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KR.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1648451762,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '664876380d0008a46fc37d62aaffff4e',
    'mtime' => 1651041540,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => 'd5c99ac0ae59240a73cecddcee606eb9',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '664876380d0008a46fc37d62aaffff4e',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ko_KRorderMapping.php.Habasit_Actions_UI_Custimization_1_3.Habasit_Actions_UI_1_9.lang.php' => 
  array (
    'md5' => '1c4403cd8737e854de316ec4576ad95c',
    'mtime' => 1651041541,
    'is_override' => false,
  ),
);