<?php
// created: 2022-04-05 07:29:06
$extensionOrderMap = array (
  'custom/Extension/modules/act_Actions/Ext/Language/ro_RO.customcom_complaints_act_actions_1.php' => 
  array (
    'md5' => '4bc6cc084ebff6d4c657d6e28196b709',
    'mtime' => 1644399101,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1644849931,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habadev10_Acction_UI_Custimization_1_1.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'e9e0ca065370d38dc577104d1ccb08a2',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
  'custom/Extension/modules/act_Actions/Ext/Language/ro_ROorderMapping.php.Habasit_Actions_UI_Custimization_1_3.lang.php' => 
  array (
    'md5' => 'b05b6c5cd1d1780e5ee8bcec8deaafb1',
    'mtime' => 1649143703,
    'is_override' => false,
  ),
);