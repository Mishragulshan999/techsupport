<?php
// created: 2022-04-20 05:01:19
$viewdefs['act_Actions']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'action_type_c' => 
    array (
    ),
    'required_implementation_date_c' => 
    array (
    ),
    'over_due_days_c' => 
    array (
    ),
    'completion_date_c' => 
    array (
    ),
  ),
);