<?php
	if (!defined('sugarEntry') || !sugarEntry)    die('Not A Valid Entry Point');
	
	class Teams_appending {
		function Complaint_Teams_In_Actions($bean, $event, $arguments) {
			
			$complaint_bean = BeanFactory::retrieveBean('Com_Complaints',$bean->complaint_relate_id_c,array('disable_row_level_security' => true));
			$teamSetBean = new \TeamSet();	
			if(!$arguments['isUpdate']) //OnCreate 
			{
			$oldTeams = $teamSetBean->getTeams($complaint_bean->team_set_id);
			foreach($oldTeams as $id=>$team){
				$teams[]=$id;
			}
			if($bean->load_relationship('teams'))
			{
				$bean->teams->add($teams);
			}
		}
		}
		
	}
?>