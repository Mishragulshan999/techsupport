<?php

require_once('modules/act_Actions/act_Actions.php');

class CustomActions extends act_Actions {

	function send_assignment_notifications($notify_user, $admin) {

		$conn = $GLOBALS['db']->getConnection();
		$sql = "SELECT value FROM config WHERE name = 'sugar_act_Actions' AND category = 'notify'";
		$stmt1 = $conn->executeQuery($sql);
		foreach($stmt1->fetchAll() as $row)
		{
			$GLOBALS['log']->fatal("CONFIG VALUE act_Actions === ".$row['value']." ===");
			if($row['value'] == 1) // send email notification
			{
				return parent::send_assignment_notifications($notify_user, $admin);
			}
		}
		return false;
		
    }
}
