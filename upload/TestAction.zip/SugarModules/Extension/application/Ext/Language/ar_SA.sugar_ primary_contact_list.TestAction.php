<?php 
$app_list_strings[' primary_contact_list'] = array (
  '' => '',
  'Yes' => 'Yes',
  'No' => 'No',
);