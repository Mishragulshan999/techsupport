<?php 
$app_list_strings['action_type_list'] = array (
  '' => '',
  'Preventive Actions' => 'Preventive Actions',
  'Corrective Actions  Short Term' => 'Corrective Actions - Short Term',
  'Corrective Actions  Long Term' => 'Corrective Actions - Long Term',
);