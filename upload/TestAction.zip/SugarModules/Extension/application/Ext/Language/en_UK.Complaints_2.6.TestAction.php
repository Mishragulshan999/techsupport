<?php 
$app_list_strings['custom_active_user_list'] = array (
  '' => '',
  '3c7b5af0_2237_11e8_a956_00155d640371' => 'ali shaikh',
  'cff58f78_b57a_11ec_9f98_00155d640281' => 'Ali Testing',
  '905c298c_a42f_11ec_982f_00155d640281' => 'Dipika Mandhare',
  '779bb118_a0a5_11ea_a16a_525400bc1097' => 'IKAM User',
  '517da974_7767_11ec_9f6c_00155d016512' => 'kartik nikode',
  '2729945c_af49_11ec_b761_00155d640281' => 'pushpendra Singh',
  '3208e12a_4b5d_11ec_bdab_00155d016512' => 'rijawan3 Shaikh',
  '6e431174_a0a5_11ea_8b19_525400bc1097' => 'Sagar Honrao',
  '11d60dc2_7f58_11ec_84f6_00155d016512' => 'Testing User',
  '0785fc04_8e2d_11ec_bd68_00155d016512' => 'Tushar Chaudhari',
  'bc64c972_9f4e_11ea_a940_525400bc1097' => 'Tushar Chaudhari',
  '48f707b6_a078_11ec_9319_00155d640281' => 'User Treator',
  'dc86c922_a077_11ec_b7c8_00155d640281' => 'User User Analyst',
  'ef750726_985a_11ec_a12d_00155d640281' => 'vaishali bhalerao',
);